APK Builder 1.1.0 — Windows x64 (portable build)
================================================

How to run:
  1. Unpack the archive into any folder.
  2. Launch APK-Builder-1.1.0.exe.
  3. The app opens in your browser at http://127.0.0.1:<port>.

No installation required: every dependency is already inside the file.
Internet and Node.js are not needed.

To stop: close the console window or press Ctrl+C.

Checksums are listed in SHA256SUMS.txt.
